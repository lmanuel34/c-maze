#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Maze.h"
#include "Creature.h"
#include "MazeSolver.h"
using namespace std;
void mazeTester()
{
	//Initial Maze
	cout << "Initializing the maze test: " << endl << endl;
	ifstream myFile("Text.txt");
	Maze myMaze(myFile);
	myMaze.display();
	// Test Boolean Functions
	cout << "Initializing Tests on squares in maze: " << endl << endl;
	cout << "isWall(0,0) returns: " << myMaze.isWall(0, 0) << "; should be 1." << endl;
	cout << "isWall(1,1) returns: " << myMaze.isWall(1, 1) << "; should be 0." << endl;
	cout << "isClear(0,0) returns: " << myMaze.isClear(0, 0) << "; should be 0." << endl;
	cout << "isClear(1,1) returns: " << myMaze.isClear(1, 1) << "; should be 1." << endl;
	cout << "isClear(4,12) returns: " << myMaze.isClear(4, 12) << "; should be 0." << endl;
	cout << "Visited(1,1) returns: " << myMaze.visited(1, 1) << "; should be 0." << endl << endl;
	Creature myCreature;
	myMaze.display();
	MazeSolver myMazeSolver;
	myMazeSolver.goNorth(myCreature, myMaze);
}

int main() {
	 
	mazeTester();
	cout << "Done Testing! Exit? <y> or <n> to run again\n";
	string y;
	getline(cin, y);
	while (y != "y")
	{
		if (y != "y" && y != "n")
		{
			cout << endl << "Invalid Input. Exit?<y>:Run Again?<n> \n";
			cout << "Enter:";
			getline(cin, y);
		}

		mazeTester();
		cout << "Done Testing! Exit? <y> or <n> to run again\n";
		getline(cin, y);
	}
	return 0;
}